"""
flatten_pdf: Utilities for flattening PDF files and preserving form fields.

Provides functions to flatten PDFs using PyMuPDF and pdfrw, and to preserve form field data and fonts.
"""

import fitz  # PyMuPDF
import os
import io

from pdfrw import PdfReader, PdfWriter, PageMerge
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from models.utils.resource_path import resource_path

def flatten_pdf(input_path, output_path):
    """Flatten a PDF file, removing form fields and saving to output.

    Parameters
    ----------
    input_path : str
        Path to the input PDF file.
    output_path : str
        Path to save the flattened PDF file.

    Returns
    -------
    str
        Path to the saved flattened PDF file.
    """
    doc = fitz.open(input_path)
    new_doc = fitz.open()

    for page in doc:
        # Create a new page with the same dimensions
        new_page = new_doc.new_page(width=page.rect.width, height=page.rect.height)

        # Copy contents from original to new page
        new_page.show_pdf_page(page.rect, doc, page.number)

    new_doc.save(resource_path("temp.pdf"))
    doc.close()
    new_doc.close()

    os.remove(input_path)
    os.replace(resource_path("temp.pdf"), output_path)
    print(f"Flattened Business App saved to: {output_path}")

    return output_path

def flatten_pdf_preserving_fields(input_path, output_path, font="lucida-console"):
    """Flatten a PDF file while preserving form field data and fonts.

    Parameters
    ----------
    input_path : str
        Path to the input PDF file.
    output_path : str
        Path to save the flattened PDF file.
    font : str, optional
        Font name to use for form fields (default: "lucida-console").
    """
    pdfmetrics.registerFont(TTFont("lucida-console", resource_path("data/fonts/LUCON.TTF")))

    # Load PDF and read form values
    template_pdf = PdfReader(input_path)
    overlays = []

    for page in template_pdf.pages:
        packet = io.BytesIO()
        can = canvas.Canvas(packet, pagesize=letter)

        if page.Annots:
            for annot in page.Annots:
                if annot.Subtype == '/Widget' and annot.T and annot.V:
                    # da = str(annot.get('/DA'))
                    # size = da.split("Tf")[0].split()[-1]
                    value = annot.V.to_unicode() if hasattr(annot.V, 'to_unicode') else str(annot.V)
                    # print(f"{value}: {size}")
                    rect = annot.Rect
                    x, y = float(rect[0]), float(rect[1])
                    height = float(rect[3]) - float(rect[1])
                    width = float(rect[2]) - float(rect[0])
                    # length = len(value)
                    # font_size = min(0.8 * height, width/(1.8 * length))

                    unit_width = pdfmetrics.stringWidth(value, font, 1)
                    size_fit_width = width / unit_width
                    size_fit_height = 0.8 * height
                    font_size = min(size_fit_width, size_fit_height)

                    can.setFont(font, font_size)
                    can.drawString(x, y+2, value)

        can.save()
        packet.seek(0)
        overlay_pdf = PdfReader(packet)
        overlays.append(overlay_pdf.pages[0])

    # Merge text overlays into the original pages
    for i, page in enumerate(template_pdf.pages):
        PageMerge(page).add(overlays[i]).render()
        page.Annots = []  # remove interactive fields

    PdfWriter().write(output_path, template_pdf)
